/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.service;

import cutpete.entitees.Produit;
import cutpete.utils.MyConnection;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;
import static jdk.nashorn.tools.ShellFunctions.input;

/**
 *
 * @author zaine
 */
public class ProduitService {

    Connection con = MyConnection.getInstance().getConnection();
    private Statement stmt;

    public ProduitService() {
        try {
            if (con != null) {
                stmt = con.createStatement();
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }

    public void ajouterProduit(Produit p) {
        try {
            String requete = "insert into produit (id_produit ,libelle_produit,categorie,prix,date_expiration,quantite,description,note,image) values (?,?,?,?,?,?,?,?,?) ";
            PreparedStatement pst = con.prepareStatement(requete);
            pst.setInt(1, p.getId_produit());
            pst.setString(2, p.getLibelle_produit());
            pst.setString(3, p.getCategorie());
            pst.setFloat(4, (Float) p.getPrix());
            pst.setString(5, p.getDate_expiration());
            pst.setInt(6, p.getQuantite());
            pst.setString(7, p.getDescription());
            pst.setInt(8, p.getNote());
            pst.setString(9, p.getImage());

            pst.executeUpdate();
            // System.out.println("Produit id="+""+stock.getId_produit()+" "+ "a ajouté dans le stock avec succés");
            System.out.println("Produit id=" + "" + p.getId_produit() + "libelle:" + "" + p.getLibelle_produit() + "Categorie:" + "" + p.getCategorie() + "prix=" + "" + p.getPrix() + "Date d expiration :" + "" + p.getDate_expiration() + "Note : " + "" + p.getNote() + "Image" + p.getImage());

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public List<Produit> Afficher() {
        List<Produit> list = new ArrayList<>();

        try {
            String requete = "SELECT * FROM produit";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                list.add(new Produit(rs.getInt("id_produit"), rs.getString("libelle_produit"), rs.getString("categorie"), rs.getFloat("prix"), rs.getString("date_expiration"), rs.getInt("quantite"), rs.getString("description"), rs.getInt("note"), rs.getString("image")));
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return list;
    }

    public void supprimerProduit(int id_produit) throws SQLException {
        String req = "DELETE FROM produit WHERE id_produit =?";
        PreparedStatement pre = con.prepareStatement(req);
        pre.setInt(1, id_produit);
        pre.executeUpdate();
    }

    public String countEvenement() {

        String req = "SELECT COUNT(*) FROM produit";
        PreparedStatement pst;
        try {
            pst = con.prepareStatement(req);
            pst.executeQuery(req);
            ResultSet rs = pst.getResultSet();
            rs.next();
            return ("Table contains " + rs.getInt("count(*)") + " rows");
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
            return null;
        }

    }

    public float CA(int id_produit) {
        Float prixx;
        try {
            String req = "SELECT * FROM produit ";
            PreparedStatement pst = con.prepareStatement(req);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                Float v = rs.getFloat("prix");
                int vs = rs.getInt("quantite");
                return prixx = v * vs;

            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return 0;

    }

    public float CATotal() {   //List<Produit> list = new ArrayList<>();
        float CATotal = 0;
        try {
            String req = "SELECT prix , quantite FROM produit  ";
            PreparedStatement pst = con.prepareStatement(req);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                CATotal += rs.getInt("quantite") * rs.getFloat("prix");

            }
            return CATotal;

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return 0;
    }

//    public void modifierProduit(Produit p, int id_produit) throws SQLException {
//        String req = "UPDATE produit SET libelle_produit=?,categorie=?,date_expiration=?,prix=?,quantite=?,description=?,note=?,image=?,id_patisserie=? WHERE id_produit=?";
//        PreparedStatement pre = con.prepareStatement(req);
//         try {
//        //Dans l'ordre
//
//        pre.setString(1, p.getLibelle_produit());
//        System.out.println("In Method");
//        pre.setString(2, p.getCategorie());
//        System.out.println("In Method1");
//        pre.setString(3, p.getDate_expiration());
//        System.out.println("In Method3");
//        pre.setFloat(4, p.getPrix());
//        System.out.println("In Method2");
//
//        pre.setInt(5, p.getQuantite());
//        System.out.println("In Method4");
//        pre.setString(6, p.getDescription());
//        System.out.println("In Method5");
//        pre.setInt(7, p.getNote());
//        System.out.println("In Method6");
//        pre.setString(8, p.getImage());
//        System.out.println("In Method7");
//
//        pre.setInt(10, id_produit);
//        System.out.println("In Method9");
//        System.out.println(pre.toString());
//        
////        pre.executeUpdate();
////        Alert alertSucc = new Alert(Alert.AlertType.CONFIRMATION);
////        alertSucc.setTitle("Succés");
////        alertSucc.setContentText("Produit modifié avec succés");
////        alertSucc.setHeaderText(null);
////        alertSucc.show();
////    }
//pre.executeUpdate();
//            System.out.println("produit modifié !");
//
//        }catch (SQLException ex) {
//            Logger.getLogger(Produit.class.getName()).log(Level.SEVERE, null, ex);
//        }}

    public boolean ModifierProduit(Produit p) throws SQLException {
        boolean test=false;
            String requete = "UPDATE produit SET libelle_produit=?,categorie=?,date_expiration=?,prix=?,quantite=?,description=?,note=? WHERE id_produit=?";
           
            PreparedStatement pst ;
            try {
               pst = con.prepareStatement(requete);
           
            pst.setString(1, p.getLibelle_produit());
            pst.setString(2,p.getCategorie());
             pst.setString(3, p.getDate_expiration()); 
            pst.setFloat(4, p.getPrix());
            pst.setInt(5, p.getQuantite());  
            pst.setString(6,p.getDescription()) ; 
            pst.setInt(7,p.getNote()); 
             pst.setInt(8, p.getId_produit());
            pst.executeUpdate();
            System.out.println("produit modifié !");
            return true;

        }catch (SQLException ex) {
            Logger.getLogger(Produit.class.getName()).log(Level.SEVERE, null, ex); 
            
        } 
    return false;}
    
    public List<String> selectCategorieProduit() throws SQLException {
        List<String> listProduit = new ArrayList<>();
        String req = "SELECT DISTINCT categorie FROM produit";
        PreparedStatement ste = con.prepareStatement(req);
        ResultSet rs = ste.executeQuery();
        while (rs.next()) {
            listProduit.add(
                    rs.getString("categorie")
            );
        }
        return listProduit;
    }

//     public List<String> selectCategorieProduit() throws SQLException {
//        List<String> listProduit = new ArrayList<>();
//        String req = "SELECT DISTINCT categorie FROM produit";
//        PreparedStatement ste = con.prepareStatement(req);
//        ResultSet rs = ste.executeQuery();
//        while (rs.next()) {
//            listProduit.add(
//                    rs.getString("categorie")
//            );
//        }
//        return listProduit;
//    }
    public List<Produit> selectProduitById(int id) throws SQLException {
        List<Produit> listProduit = new ArrayList<>();
        String req = "SELECT * FROM produit where id_produit=?";
        PreparedStatement ste = con.prepareStatement(req);
        ste.setInt(1, id);
        ResultSet rs = ste.executeQuery();
        while (rs.next()) {
            listProduit.add(new Produit(
                    rs.getInt("id_produit"),
                    rs.getString("libelle_produit"),
                    rs.getFloat("prix"),
                    rs.getString("date_expiration"),
                    rs.getInt("quantite")
            ));
        }
        return listProduit;
    }

    public List<Produit> selectProduit(String categorie) throws SQLException {
        List<Produit> listProduit = new ArrayList<>();
        String req = "SELECT * FROM produit where categorie=?";
        PreparedStatement ste = con.prepareStatement(req);
        ste.setString(1, categorie);
        ResultSet rs = ste.executeQuery();
        while (rs.next()) {
            listProduit.add(new Produit(
                    rs.getInt("id_produit"),
                    rs.getString("libelle_produit"),
                    rs.getFloat("prix"),
                    rs.getString("date_expiration"),
                    rs.getInt("quantite")
            ));
        }
        return listProduit;
    }

    public List<Produit> selectAllProduit() throws SQLException {
        List<Produit> listProduit = new ArrayList<>();
        String req = "SELECT * FROM produit";
        PreparedStatement ste = con.prepareStatement(req);
        ResultSet rs = ste.executeQuery();
        while (rs.next()) {
            listProduit.add(new Produit(
                    rs.getInt("id_produit"),
                    rs.getString("libelle_produit"),
                    rs.getFloat("prix"),
                    rs.getString("date_expiration"),
                    rs.getInt("quantite")
            ));
        }
        return listProduit;
    }

    

}
