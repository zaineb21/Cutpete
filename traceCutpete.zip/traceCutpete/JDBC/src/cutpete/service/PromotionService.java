/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.service;

//import cutpete.entitees.Produit;
import cutpete.entitees.Promotion;
import cutpete.utils.MyConnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Alert;

import cutpete.entitees.Produit;
import java.text.SimpleDateFormat;

/**
 *
 * @author zaine
 */
public class PromotionService {

    Connection con = MyConnection.getInstance().getConnection();
    private Statement stmt;

    public PromotionService() {
        try {
            if (con != null) {
                stmt = con.createStatement();
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }

    public void ajouterPromotion(Promotion promotion) {

        try {
            String requete = "insert into promotion (libelle_promotion,pourcentage,date_debut_promotion,date_fin_pourcentage,description ,id_produit)values(?,?,?,?,?,?)";
            PreparedStatement pre = con.prepareStatement(requete);
            Date CreatedDate = new Date(System.currentTimeMillis());
            pre.setString(1, promotion.getLibelle_promotion());
            pre.setFloat(2, promotion.getPourcentage());
            pre.setDate(3, promotion.getDate_debut());
            pre.setDate(4, promotion.getDate_fin());
            pre.setString(5, promotion.getDescription());
            pre.setInt(6, promotion.getId_produit());
//            
            pre.executeUpdate();

            System.out.println("promotion ajoutée !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public List<Promotion> afficherPromotion() {
        List<Promotion> listP = new ArrayList<>();
        ProduitService ps = new ProduitService();

        try {
            String requete = "SELECT * FROM promotion";
            PreparedStatement pst = con.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {

                ////////////////
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = simpleDateFormat.format(rs.getDate(4));
                java.sql.Date date1 = java.sql.Date.valueOf(formattedDate);

                SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate1 = simpleDateFormat1.format(rs.getDate(5));
                java.sql.Date date2 = java.sql.Date.valueOf(formattedDate1);

                //System.out.println("===> " + formattedDate);
                ////////////////
                listP.add(new Promotion(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getDate(4), rs.getDate(5), rs.getString(6), rs.getInt(7)));
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return listP;
    }

    public void Supprimer(int id_promotion) throws SQLException {
        String req = "DELETE FROM promotion WHERE id_promotion =?";
        PreparedStatement pre = con.prepareStatement(req);
        pre.setInt(1, id_promotion);
        pre.executeUpdate();
    }

    public boolean Modifier(Promotion r ) {
        try {
            String requete = "UPDATE promotion SET Libelle_promotion=?,Pourcentage=?,date_debut_promotion=?,date_fin_pourcentage=?,Description=? WHERE id_promotion=?";
            PreparedStatement ste = con.prepareStatement(requete);

            ste.setString(1, r.getLibelle_promotion());
            ste.setFloat(2, r.getPourcentage());
            ste.setDate(3, (Date) r.getDate_debut());
            ste.setDate(4, (Date) r.getDate_fin());
            ste.setString(5, r.getDescription());
//            ste.setInt(6, r.getId_produit());
            ste.setInt(6, r.getId_promotion());
            ste.executeUpdate();
            System.out.println("Promotion modifiée !");
            return true;

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return false;
    }

    public float CalculPrixPromotion(int id_produit) {
        Float prixx;
        try {
            String req = "SELECT * FROM produit as p join promotion as  s where s.id_produit=p.id_produit ";
            PreparedStatement pst = con.prepareStatement(req);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
//     rs.next();
                Float v = rs.getFloat("prix");
                Float vs = rs.getFloat("pourcentage");
                return prixx = v - (vs*v);

            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return 0;

    }
    public int selectPromotionAjouter(Promotion promotion) throws SQLException {
        String req = "SELECT * FROM promotion where libelle_promotion=? and date_debut=? and date_fin=?  and description=?";
        PreparedStatement ste = con.prepareStatement(req);
        ste.setString(1, promotion.getLibelle_promotion());
        ste.setDate(2, (Date) promotion.getDate_debut());
        ste.setDate(3, (Date) promotion.getDate_fin());
        ste.setString(4, promotion.getDescription());
        ResultSet rs = ste.executeQuery();
        while (rs.next()) {
            return rs.getInt("id_promotion");
        }
        return -1;
    }

//    public void ajouterProduitPromotion(int id_produit, int id_promotion, Float prix_promotion) throws SQLException {
//        String req = "INSERT INTO produit_promotion values(?,?,?)";
//        PreparedStatement pre = con.prepareStatement(req);
//        pre.setInt(1, id_produit);
//        pre.setInt(2, id_promotion);
//        pre.setFloat(3, prix_promotion);
//        pre.execute();
//    }
//
//    public void deleteProduitPromotion(int id) throws SQLException {
//        String req = "DELETE FROM produit_promotion WHERE id_promotion =?";
//        PreparedStatement ste = con.prepareStatement(req);
//        ste.setInt(1, id);
//        ste.executeUpdate();
//        System.out.println("DONEEEE DELETED");
//    }
   

}
