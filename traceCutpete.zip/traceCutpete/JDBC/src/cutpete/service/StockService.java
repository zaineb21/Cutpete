/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.service;

//import cutpete.entitees.Produit;
import cutpete.entitees.Produit;
import cutpete.entitees.Stock;
import cutpete.utils.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import cutpete.entitees.Stock;
//import java.util.logging.Level;
//import java.util.logging.Logger;

/**
 *
 * @author zaine
 */
public class StockService {

    Connection con = MyConnection.getInstance().getConnection();
    private Statement stmt;

    public StockService() {
        try {
            stmt = con.createStatement();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }

    public void AjouerStock(Stock r) {
        try {
            String requete = "insert into stock (id_stock , id_produit  ) values (?,?) ";
            PreparedStatement pst = con.prepareStatement(requete);
           
            pst.setInt(1, r.getId_stock());
             pst.setInt(2, r.getId_produit());

            pst.executeUpdate();
            System.out.println("Stock rempli !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public void Supprimer(Stock r) {
        try {
            String requete = "DELETE FROM stock WHERE id_stock=?";
            PreparedStatement pst = con.prepareStatement(requete);
            pst.setInt(1, r.getId_stock());
            pst.executeUpdate();
            System.out.println("stock supprimé !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public void Modifier(Stock r) {
        try {
            String requete = "UPDATE stock SET id_produit=? WHERE id_stock=?";
            PreparedStatement pst = con.prepareStatement(requete);

            pst.setInt(1, r.getId_stock());
            
            pst.setInt(2, r.getId_produit());

            pst.executeUpdate();
            System.out.println("Stock modifié !");

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public List<Stock> Afficher() {
        List<Stock> list = new ArrayList<>();

        try {
            String requete = "SELECT * FROM stock";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(requete);
            while (rs.next()) {
                list.add(new Stock( rs.getInt("id_stock"),rs.getInt("id_produit")));
            }

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return list;
    }


    public float CalculNbProduit (){
     int nb=0 ;
     try {
          String req = "SELECT quantite FROM produit id_produit ";
           PreparedStatement pst = con.prepareStatement(req);
            ResultSet rs = pst.executeQuery();
            //pst.setString(1, m);
            
        while (rs.next()) {
           
          nb+=rs.getInt("quantite");
                      
           }
        return nb;
        

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return 0;   
     
 }
    public float CalculNbProduitProduit (Produit p){
int nb=0;
     try {
          String req = "SELECT quantite FROM produit p join stock s  where p.id_produit=s.id_produit ";
           PreparedStatement pst = con.prepareStatement(req);
            ResultSet rs = pst.executeQuery();
            //pst.setString(1, m);
            
        while (rs.next()) {
           
          nb=rs.getInt("quantite");
                      
           }
        return nb;
        

        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }

        return 0;   
}
}