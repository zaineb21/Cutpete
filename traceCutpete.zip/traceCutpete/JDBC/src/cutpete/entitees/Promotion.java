/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.entitees;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;

/**
 *
 * @author zaine
 */
public class Promotion  {
     private int id_promotion;
    private String libelle_promotion;
    private float pourcentage;
    private Date date_debut;
    private Date date_fin;
    private String description;
    private int id_produit;
    //List <Produit> listProduit = new ArrayList<>();
public Promotion() {}

    public Promotion(int id_promotion, String libelle_promotion, float pourcentage, Date date_debut, Date date_fin, String description) {
        this.id_promotion = id_promotion;
        this.libelle_promotion = libelle_promotion;
        this.pourcentage = pourcentage;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.description = description;
        
    }
    

    public Promotion(int id_promotion, String libelle_promotion, float pourcentage, Date date_debut, Date date_fin, String description, int id_produit) {
        this.id_promotion = id_promotion;
        this.libelle_promotion = libelle_promotion;
        this.pourcentage = pourcentage;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.description = description;
        this.id_produit = id_produit;
    }
       public Promotion( String libelle_promotion, float pourcentage, Date date_debut, Date date_fin, String description, int id_produit) {
        this.libelle_promotion = libelle_promotion;
        this.pourcentage = pourcentage;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.description = description;
        this.id_produit = id_produit;
    }
     

    public Promotion(String libelle_promotion, float pourcentage, Date date_debut, Date date_fin, String description) {
        this.libelle_promotion = libelle_promotion;
        this.pourcentage = pourcentage;
        this.date_debut = date_debut;
        this.date_fin = date_fin;
        this.description = description;
       
    }

    public Promotion(String libelle_promotion, float pourcentage, String description) {
        this.libelle_promotion = libelle_promotion;
        this.pourcentage = pourcentage;
        this.description = description;
      
    }
    

//    public Promotion(String text, int pourcentage, Date dateDebut, Date dateFin, String text0, String text1) {
//        
//    }
//
//    public Promotion(String text, int parseInt, String text0, String text1, String text2, int parseInt0) {
//        
//    }
//
//    public Promotion(int parseInt, String text, int parseInt0, TableColumn<?, ?> txtDateDebut, TableColumn<?, ?> txtDateFin, String text0, int parseInt1) {
//        
//    }
//
////    public Promotion(int parseInt, String text, int parseInt0, String text0, String text1, String text2, int parseInt1) {
////        
////    }
//
//    public Promotion(int parseInt, String text, int parseInt0, DatePicker txtDateDebut1, DatePicker txtDateFin1, String text0, int parseInt1) {
//         }
//
//    public Promotion(int i, String gigi, int i0, java.util.Date date7, java.util.Date date8, String h, int i1) {
//       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    public Promotion(int parseInt, String text, int parseInt0, DatePicker txtDateDebut1, DatePicker txtDateFin1, String text0, int parseInt1) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Promotion(int parseInt, String text, int parseInt0, DatePicker txtDateDebut1, DatePicker txtDateFin1, String text0) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Promotion(int parseInt, String text, float parseFloat, DatePicker txtDateDebut1, DatePicker txtDateFin1, String text0) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Promotion(int aInt, String string, String string0, float aFloat, String string1, int aInt0, String string2, int aInt1, String string3) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    
    
    

    public int getId_promotion() {
        return id_promotion;
    }

    public void setId_promotion(int id_promotion) {
        this.id_promotion = id_promotion;
    }

    public String getLibelle_promotion() {
        return libelle_promotion;
    }

    public void setLibelle_promotion(String libelle_promotion) {
        this.libelle_promotion = libelle_promotion;
    }

    public float getPourcentage() {
        return pourcentage;
    }

    public void setPourcentage(float pourcentage) {
        this.pourcentage = pourcentage;
    }

    public Date getDate_debut() {
        return date_debut;
    }

    public void setDate_debut(Date date_debut) {
        this.date_debut = date_debut;
    }

    public Date getDate_fin() {
        return date_fin;
    }

    public void setDate_fin(Date date_fin) {
        this.date_fin = date_fin;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

  
//    public List<Produit> getListProduit() {
//        return listProduit;
//    }
//
//    public void setListProduit(List<Produit> listProduit) {
//        this.listProduit = listProduit;
//    }

    public int getId_produit() {
        return id_produit;
    }

    public void setId_produit(int id_produit) {
        this.id_produit = id_produit;
    }
    

    @Override
    public String toString() {
        return "Promotion{" + "id_promotion=" + id_promotion + ", libelle_promotion=" + libelle_promotion + ", pourcentage=" + pourcentage + ", date_debut=" + date_debut + ", date_fin=" + date_fin + ", description=" + description + ",id_produit="+id_produit+/*", listProduit=" + listProduit + */'}';
    }
    
    
}
