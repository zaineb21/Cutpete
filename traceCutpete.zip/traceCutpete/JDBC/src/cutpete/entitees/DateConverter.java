/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.entitees;
import java.util.Date;

//import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
   import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author zaine
 */
public class DateConverter {
    

 

    public static void main(String[] args) throws IllegalArgumentException {
        Date date = new Date();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        String formattedDate = simpleDateFormat.format(date);

        java.sql.Date date1 = java.sql.Date.valueOf(formattedDate);

        System.out.println("SQL Date: " + date1);
    }
}
    
//    public static java.sql.Date dateConverter(java.util.Date d) throws ParseException{
//            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
//            String currentTime = sdf.format(d);
//            Date myDate = formatter.parse(currentTime);
//            java.sql.Date sqlDate = new java.sql.Date(myDate.getTime());
//        return sqlDate;    
//    }


