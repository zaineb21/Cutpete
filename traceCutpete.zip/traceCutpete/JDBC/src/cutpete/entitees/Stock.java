/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.entitees;

/**
 *
 * @author zaine
 */
public class Stock {
     private int id_stock;
    private int id_produit;  
   

    public Stock() {
    }

   

    public Stock(int id_stock, int id_produit) {
        this.id_stock = id_stock;
        this.id_produit = id_produit;
        
    }
   

   public Stock(int id_produit) {
        this.id_produit = id_produit;
    }
    
    
    

    public int getId_produit() {
        return id_produit;
    }

    public int getId_stock() {
        return id_stock;
    }

    

    public void setId_produit(int id_produit) {
        this.id_produit = id_produit;
    }

    public void setId_stock(int id_stock) {
        this.id_stock = id_stock;
    }

   

    @Override
    public String toString() {
        return "Stock{" + "id_stock=" + id_stock + ", id_produit=" + id_produit +  '}';
    }
    

    
}
