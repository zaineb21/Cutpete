/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.entitees;

//import java.sql.Date;

import java.sql.Date;
import static javafx.beans.binding.Bindings.select;
import static javafx.beans.binding.Bindings.select;
import static javafx.beans.binding.Bindings.select;
import static javafx.beans.binding.Bindings.select;
import static javafx.beans.binding.Bindings.select;
import static javafx.beans.binding.Bindings.select;
import static javafx.beans.binding.Bindings.select;
import static javafx.beans.binding.Bindings.select;
import javafx.scene.control.CheckBox;


/**
 *
 * @author zaine
 */
public class Produit {
     private int id_produit;
    private String libelle_produit;
    private String categorie;
    private float prix;
    private String date_expiration;
    private int quantite;
    private String description;
    private int note;
    private String image;
    private CheckBox select ;
	 private Float prixPromotion;
     public Produit() {
    }

    public Produit(int id_produit, int quantite) {
        this.id_produit = id_produit;
        this.quantite = quantite;
    }

    //libelle,categorie,prix,Qte,desc,note

    public Produit(String libelle_produit, String categorie, float prix, String date_expiration, int quantite, String description, int note) {
        this.libelle_produit = libelle_produit;
        this.categorie = categorie;
        this.prix = prix;
        this.date_expiration = date_expiration;
        this.quantite = quantite;
        this.description = description;
        this.note = note;
    }
    
    

    public Produit(int id_produit, String libelle_produit, String categorie, float prix, String date_expiration, int quantite, String description, int note, String image) {
        this.id_produit = id_produit;
        this.libelle_produit = libelle_produit;
        this.categorie = categorie;
        this.prix = prix;
        this.date_expiration = date_expiration;
        this.quantite = quantite;
        this.description = description;
        this.note = note;
        this.image = image;
    }
    
    

    public Produit(int id_produit, String libelle_produit, String categorie, float prix, String date_expiration, int quantite, String description, int note) {
        this.id_produit = id_produit;
        this.libelle_produit = libelle_produit;
        this.categorie = categorie;
        this.prix = prix;
        this.date_expiration = date_expiration;
        this.quantite = quantite;
        this.description = description;
        this.note = note;
    }
    public Produit(int id_produit, String libelle_produit, String categorie, float prix, String date_expiration, int quantite, String description) {
		this.id_produit = id_produit;
		this.libelle_produit = libelle_produit;
		this.categorie = categorie;
		this.prix = prix;
		this.date_expiration = date_expiration;
		this.quantite = quantite;
		this.description = description;
	}
//
    public Produit(int id_produit, String libelle_produit, float prix, String date_expiration, int quantite) {
        this.id_produit = id_produit;
        this.libelle_produit = libelle_produit;
        this.prix = prix;
        this.date_expiration = date_expiration;
        this.quantite = quantite;
    }

    public Produit(String libelle_produit, String categorie, float prix, String date_expiration, int quantite, String description, int note, String image) {
        this.libelle_produit = libelle_produit;
        this.categorie = categorie;
        this.prix = prix;
        this.date_expiration = date_expiration;
        this.quantite = quantite;
        this.description = description;
        this.note = note;
        this.image = image;
    }

//    public Produit(String text, String text0, String text1, float parseFloat, int parseInt, String text2, int parseInt0, String path) {
//        
//    }

    public Produit(int id_produit) {
        this.id_produit = id_produit;
    }

   

//    public Produit(int parseInt, String text, String text0, String text1, float parseFloat, int parseInt0, String text2, int parseInt1) {
//        
//    }
//
//    public Produit(String text, String text0, String text1, float parseFloat, int parseInt, String text2, int parseInt0, int parseInt1) {
//       
//    }

    public Produit(String text, String text0, String text1, float parseFloat, int parseInt, String text2, int parseInt0, int parseInt1) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Produit(int parseInt, String text, String text0, String text1, float parseFloat, int parseInt0, String text2, int parseInt1) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   


public int getId_produit() {
        return id_produit;
    }

    public void setId_produit(int id_produit) {
        this.id_produit = id_produit;
    }

    public String getLibelle_produit() {
        return libelle_produit;
    }

    public void setLibelle_produit(String libelle_produit) {
        this.libelle_produit = libelle_produit;
    }

     public CheckBox getSelect(){
    return select;
    }
      public void setSelect(CheckBox select)
    {
    this.select=select ;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public float getPrix() {
        return prix;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public String getDate_expiration() {
        return date_expiration;
    }

    public void setDate_expiration(String date_expiration) {
        this.date_expiration = date_expiration;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getNote() {
        return note;
    }

    public void setNote(int note) {
        this.note = note;
    }

    public String getImage() {
        return image;
    }
    
    @Override
	public String toString() {
		return "Produit{" + "id_produit=" + id_produit + ", libelle_produit=" + libelle_produit + ", categorie=" + categorie + ", prix=" + prix + ", date_expiration=" + date_expiration + ", quantite=" + quantite + ", description=" + description + ", note=" + note +  '}';
	}

    
}
