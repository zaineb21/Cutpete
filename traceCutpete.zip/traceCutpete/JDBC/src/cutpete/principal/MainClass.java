/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.principal;

import cutpete.utils.MyConnection;
import cutpete.entitees.Produit;
import cutpete.entitees.Promotion;
import cutpete.entitees.Stock;
import cutpete.service.ProduitService;
import cutpete.service.PromotionService;
import cutpete.service.StockService;
import cutpete.entitees.DateConverter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

//import java.text.SimpleDateFormat;
//import java.util.Locale;
/**
 *
 * @author zaine
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ParseException {

        FileInputStream input = null;
       // try {
            MyConnection mc = MyConnection.getInstance();
            /////////////////////////////////Produit
//ProduitService ps = new ProduitService();
//            //l'image a inserer 
//           // File file = new File("C:\\Users\\zaine\\Desktop\\im.jpg");
//            //input = new FileInputStream(file);
//            Produit p = new Produit( "Croquette", "Croquette chien", 30.5f, "01/01/2025", 40, "Aliment complet et équilibrée pour chiens adultes actifs de taille moyenne , répond a leurs besoins énergétiques élevée.", 7,"C:\\Users\\zaine\\Desktop\\im.jpg");
//            Produit p1 = new Produit( "Croquette", "Croquette chat", 20.0f, "12/02/2022", 40, "Croquettes pour chat adulte au Boeuf. Formule équilibrée en minéraux", 6, "");
//            Produit p2 = new Produit( "Accesoires ", "Accesoires pour chien ", 6, "", 40, "Laisse en simple épaisseur et nylon , fonctionnelle en apportant tout confort.", 2, "");
//            ps.ajouterProduit(p2);
//            ps.ajouterProduit(p);
//            ps.ajouterProduit(p1);
//            ps.Afficher().forEach(System.out::println);
//            ps.selectCategorieProduit().forEach(System.out::println);
//            ps.selectProduitById(10).forEach(System.out::println);
            
       
            
            // ps.supprimerProduit(1092);
          //  ps.ModifierProduit(new Produit(1093,"k", "Croquette chien", 30.5f, "01/01/2025", 40, "Aliment complet et équilibrée pour chiens adultes actifs de taille moyenne , répond a leurs besoins énergétiques élevée.", 7,"C:\\Users\\zaine\\Desktop\\im.jpg"),1093);
            //System.out.println(ps.CATotal());
//            String som = ps.countEvenement();
//            System.out.println(som);
//            System.out.println(ps.CA(1004));
            //////////////////////////////////// STOCK
//            StockService ss = new StockService();
//            Stock s=new Stock (1038);
//            ss.AjouerStock(s);
//           // ss.Afficher().forEach(System.out::println);
//   ss.Supprimer(s);
//            //ss.Modifier(new Stock(2,2) );
//           System.out.println(ss.CalculNbProduitProduit(p2));
////
//       
/////////////////////////////////Promotion +
//        String sDate7 = "2020/02/02";
//        String sDate8 = "2022/02/21";
//        java.util.Date date7 = new SimpleDateFormat("yyyy/MM/DD").parse(sDate7);
//        java.util.Date date8 = new SimpleDateFormat("yyyy/MM/DD").parse(sDate8);
//        //System.out.println(date7);
//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//        String formattedDate = simpleDateFormat.format(date7);
//       // System.out.println(formattedDate);
//        java.sql.Date date1 = java.sql.Date.valueOf(formattedDate);
//        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
//        String formattedDate1 = simpleDateFormat1.format(date8);
//        java.sql.Date date2 = java.sql.Date.valueOf(formattedDate1);
//       // System.out.println(date2);
//
//java.sql.Date dd,df;
//dd=new java.sql.Date(122,2,20);
//        System.out.println(dd.getDay());
//df=new java.sql.Date(2022,4,20);
//        PromotionService promo = new PromotionService();
//       
//        Promotion promo1 = new Promotion("Promo fin d'année", 0.2f, date1, date2, "faites vites , promo exceptionelle ",1037);
//          //promo.afficherPromotion().forEach(System.out::println);
//
//       // promo.ajouterPromotion(promo1);
//             
//     //System.out.println("prix aprés promotion :"+promo.CalculPrixPromotion(1004));
////     promo.selectProduitPromotion(promo1,25).forEach(System.out::println);
////
////     
////       promo.selectProduitPromotion(promo1,25).forEach(System.out::println);
////       
//        promo.Modifier(new Promotion (33,"Promo ", 0.2f, date1, date2, " promo exceptionelle "));
//        //promo.Supprimer(32);
//    }
       
}}
