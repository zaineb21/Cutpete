/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.GUI;

import cutpete.entitees.Produit;
import cutpete.entitees.Promotion;
import cutpete.service.ProduitService;
import cutpete.service.PromotionService;
import cutpete.utils.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author zaine
 */
public class ModifierPromotionController implements Initializable {
    
    @FXML
    private TableView<Promotion> table;
    @FXML
    private Button modifierpromotion;
    private ResultSet res = null;
    Connection con = MyConnection.getInstance().getConnection();
    private Statement stmt;
    
   
    @FXML
    private TextField txtLibelle1;
    @FXML
    private TextField txtPourcentage1;
    @FXML
    private TextArea txtDescription1;
    @FXML
    private DatePicker txtDateDebut1;
    @FXML
    private DatePicker txtDateFin1;
    @FXML
    private TextField id_promotion;
    @FXML
    private TableColumn<Promotion, String> Libelle;
    @FXML
    private TableColumn<Promotion, Float> Pourcentage;
//    private TableColumn<Promotion, Date> DateDebut;
//    private TableColumn<Promotion, Date> DateFin;
    @FXML
    private TableColumn<Promotion, String> Description;
    @FXML
    private TableColumn<Promotion, Integer> IdProd;
//    List<Integer> ListIdProduit;
//    List<Produit> listProduit;
    int id;
    Promotion promot;
//    private TextField id_produit;
//    @FXML
    @FXML
    private TextField prixpromo;
    @FXML
    private TextField id_produitcalcul;
    @FXML
    private TableColumn<Promotion, Date> DateDebutPromo;
    @FXML
    private TableColumn<Promotion, Date> DateFinPromo;
    @FXML
    private Button afficherProm;
     List<Integer> ListIdProduit;
     List<Produit> listProduit;
      ObservableList<Promotion> data;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }

//    @FXML
//    private void modifierPromotion(ActionEvent event) {
//
//        PromotionService ps = new PromotionService();
//        Promotion p = new Promotion(Integer.parseInt(id_promotion.getText()), txtLibelle.getText(), Integer.parseInt(txtPourcentage.getText()), txtDateDebut.getText(), txtDateFin.getText(), txtDescription.getText(), Integer.parseInt(txtIdProd.getText()));
//        ps.Modifier(p, 0);
//        Alert a = new Alert(AlertType.INFORMATION);
//        a.setContentText("promo modifiée");
//        a.show();
//    }
   
    private void supprimerPromo(ActionEvent event) throws SQLException {
        
    }
    
    public static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        
        return true;
    }

    private boolean validateInputs() {
        
        if ((txtLibelle1.getText().isEmpty()) || (txtDescription1.getText().isEmpty())
                || (txtPourcentage1.getText().isEmpty())
                || (txtDateDebut1.getValue() == null)
                || (txtDateFin1.getValue() == null)) {
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Erreur");
            alert1.setContentText("Veillez remplir tout les champs");
            alert1.setHeaderText(null);
            alert1.show();
            return false;
        }
        if (!isInteger(txtPourcentage1.getText())) {
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Erreur");
            alert1.setContentText("Veillez saisir un nombre dans le champ pourcentage");
            alert1.setHeaderText(null);
            alert1.show();
            return false;
        }
        
        return true;
    }

//    private List<Integer> getIdProduit() {
//        ListIdProduit = new ArrayList<>();
//        for (Produit produit : listProduit) {
//            if (produit.getSelect().isSelected()) {
//                ListIdProduit.add(produit.getId_produit());
//            }
//        }
//        return ListIdProduit;
//    }
    private List<Integer> getIdProduit() {
        ListIdProduit = new ArrayList<>();
        for (Produit produit : listProduit) {
            if (produit.getSelect().isSelected()) {
                ListIdProduit.add(produit.getId_produit());
            }
        }
        return ListIdProduit;
    }

    @FXML
    private void modifierPromotion(MouseEvent event) {
        PromotionService ps = new PromotionService();
        if(validateInputs()){
        Date dateDebut = Date.valueOf(txtDateDebut1.getValue());
        Date dateFin = Date.valueOf(txtDateFin1.getValue());
            float pourcentage = Float.parseFloat(txtPourcentage1.getText());
        

        Promotion p = new Promotion(Integer.parseInt(id_promotion.getText()), txtLibelle1.getText(), pourcentage, dateDebut, dateFin, txtDescription1.getText());
        ps.Modifier(p);
        if(ps.Modifier(p)==true)
        {Alert a = new Alert(AlertType.INFORMATION);
        a.setContentText("promo modifiée");
        a.show();}
        else {
            Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText("Promotion non" );
        }
       
    } }

    @FXML
    private void prixpromo(ActionEvent event) {
        PromotionService pr=new PromotionService();
        float a=0;
        a=pr.CalculPrixPromotion(Integer.parseInt(id_produitcalcul.getText()));
        prixpromo.setText(Float.toString(a)+"DT");
        
    }

//    @FXML
//     private void afficherProm(MouseEvent event) {
//         con = MyConnection.getInstance().getConnection();
//        //System.out.println("test");
//        
//        try {
////        Date dateDebut = Date.valueOf(txtDateDebut.getValue());
////        Date dateFin = Date.valueOf(txtDateFin.getValue());
//            // Connection co=dc.getInstance().getConnection();
//            data = FXCollections.observableArrayList();
//           // System.out.println("test");
//            PromotionService ps = new PromotionService();
//            
//            String req = "SELECT * FROM promotion ";
//            PreparedStatement pre = con.prepareStatement(req);
//            
//            ResultSet rs = pre.executeQuery();
//            //System.out.println("test2");
//            
//            while (rs.next()) {
//                
//                data.add(new Promotion(
//                        rs.getString("libelle_promotion"),
//                        rs.getFloat("pourcentage"),
//                        rs.getDate("date_debut_promotion"),
//                        rs.getDate("date_fin_pourcentage"),
//                        rs.getString("description"),
//                        rs.getInt("id_produit")
//                ));
//            }
//            
//            Libelle.setCellValueFactory(new PropertyValueFactory<>("libelle_promotion"));
//            Pourcentage.setCellValueFactory(new PropertyValueFactory<>("pourcentage"));
//            DateDebutPromo.setCellValueFactory(new PropertyValueFactory<>("date_debut_promotion"));
//            DateFinPromo.setCellValueFactory(new PropertyValueFactory<>("date_fin_pourcentage"));
//            Description.setCellValueFactory(new PropertyValueFactory<>("description"));
//            IdProd.setCellValueFactory(new PropertyValueFactory<>("id_produit"));
//            table.setItems(data);
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//    }
//
//   
//
//    @FXML
//    private void supprimerPromo(MouseEvent event) throws SQLException {
//        PromotionService sv=new PromotionService();
//         ObservableList<Promotion> promoselected, allPromo;      
//        allPromo = table.getItems();
//        promoselected = table.getSelectionModel().getSelectedItems();
//
//        int id_promotion =promoselected.get(0).getId_promotion();
//        System.out.println(""+id_promotion);
//        sv.Supprimer(id_promotion);
//       
//        promoselected.forEach(allPromo::remove);
//                System.out.println("produit supprimé avec succès !! ");
//    }

//    @FXML
//    private void afficherProm(MouseEvent event) {
//        PromotionService sv = new PromotionService();
//		
//		
//         Libelle.setCellValueFactory(new PropertyValueFactory<>("libelle_promotion"));
//            Pourcentage.setCellValueFactory(new PropertyValueFactory<>("pourcentage"));
//            DateDebutPromo.setCellValueFactory(new PropertyValueFactory<>("date_debut_promotion"));
//            DateFinPromo.setCellValueFactory(new PropertyValueFactory<>("date_fin_pourcentage"));
//            Description.setCellValueFactory(new PropertyValueFactory<>("description"));
//            IdProd.setCellValueFactory(new PropertyValueFactory<>("id_produit"));
//            table.setItems(data);
//    }

    @FXML
   private void afficherProm(MouseEvent event) {
       con = MyConnection.getInstance().getConnection();
        System.out.println("test");
         
        
        try {
            data = FXCollections.observableArrayList();
            System.out.println("test");
			PromotionService ps=new PromotionService();
			String req="SELECT * FROM promotion ";
			PreparedStatement pre=con.prepareStatement(req);
			   
            ResultSet rs = pre.executeQuery();
            System.out.println("test2");
            
            while (rs.next()) {
               // data.add(new Produit(rs.getInt("id_produit")));
                data.add(new Promotion(rs.getString("libelle_promotion"),
                        rs.getFloat("pourcentage"),
                        rs.getDate("date_debut_promotion"),
                        rs.getDate("date_fin_pourcentage"),
                        rs.getString("description"),
                        rs.getInt("id_produit")
                        
                ));
                
                

            }
            
            Libelle.setCellValueFactory(new PropertyValueFactory<>("libelle_promotion"));
            Pourcentage.setCellValueFactory(new PropertyValueFactory<>("pourcentage"));
            DateDebutPromo.setCellValueFactory(new PropertyValueFactory<>("date_debut_promotion"));
            DateFinPromo.setCellValueFactory(new PropertyValueFactory<>("date_fin_pourcentage"));
            Description.setCellValueFactory(new PropertyValueFactory<>("description"));
            IdProd.setCellValueFactory(new PropertyValueFactory<>("id_produit"));
            table.setItems(data);
        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    @FXML
    private void supprimerPromo(MouseEvent event) throws SQLException {
         PromotionService sv=new PromotionService();
         ObservableList<Promotion> promoselected, allPromo;      
        allPromo = table.getItems();
        promoselected = table.getSelectionModel().getSelectedItems();

        int id_promotion =promoselected.get(0).getId_promotion();
        System.out.println(""+id_promotion);
        sv.Supprimer(id_promotion);
       
        promoselected.forEach(allPromo::remove);
                System.out.println("produit supprimé avec succès !! ");
    }

    @FXML
    private void retourAjouter(ActionEvent event) throws IOException {
         //////redirectin////////
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AjouterPromotion.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.initStyle(StageStyle.UNDECORATED);
        stage.setTitle("ABC");
        stage.setScene(new Scene(root1));
        stage.show();
    }
   }

   
