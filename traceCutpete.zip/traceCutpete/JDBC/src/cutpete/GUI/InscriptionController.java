/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.GUI;

import cutpete.entitees.Stock;
import cutpete.service.StockService;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author zaine
 */
public class InscriptionController implements Initializable {

    @FXML
    private TextField id_stock;
    @FXML
    private TextField id_produit;
    @FXML
    private Button btnAjouterStock;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Save_Stock(ActionEvent event) {
        try {
            ////Sauvgarde /////
            int id=Integer.parseInt(id_stock.getText());
            int id2=Integer.parseInt(id_produit.getText());
            Stock s= new Stock(id , id2);
            StockService pcd = new StockService();
            pcd.AjouerStock(s);
            
            //////redirectin////////
            FXMLLoader loader = new  FXMLLoader(getClass().getResource("StockDetails.fxml"));
            Parent root=loader.load();
            StockDetailsController pdc = loader.getController();
            pdc.setAfficher_id_produit(s.getId_produit()+"");
            pdc.setAfficher_id_stock(s.getId_stock()+"");
            
            id_produit.getScene().setRoot(root);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        
        
    }
    
}
