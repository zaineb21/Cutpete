/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.GUI;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author zaine
 */
public class StockDetailsController implements Initializable {

    @FXML
    private TextField Afficher_id_stock;
    @FXML
    private TextField Afficher_id_produit;

    public void setAfficher_id_stock(String contenu) {
        this.Afficher_id_stock.setText(contenu);
    }

    public void setAfficher_id_produit(String contenu) {
        this.Afficher_id_produit.setText(contenu);
    }



    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
