/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.GUI;

import cutpete.entitees.Produit;
import cutpete.service.ProduitService;
import cutpete.utils.MyConnection;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * FXML Controller class
 *
 * @author zaine
 */
public class ModifierProduitController implements Initializable {

    private Produit selectedid;
    @FXML
    private Button ButtonModifier;
    String path = "";
    private ImageView imageViewProduit;
    @FXML
    private TextField txtLibelle;
    @FXML
    private TextField txtCategorie;
    @FXML
    private TextField txtDate;
    @FXML
    private TextField txtPrix;
    @FXML
    private TextField txtQuantite;
    @FXML
    private TextField txtDescription;
    @FXML
    private TextField txtNote;
    @FXML
    private TextField txtId_produit;
    // private Connection con;
    PreparedStatement prepared = null;
    private ResultSet res = null;
    Connection con = MyConnection.getInstance().getConnection();
    private Statement stmt;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    private void importImage(ActionEvent event) throws MalformedURLException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE", "jpg", "gif", "png");
        fileChooser.addChoosableFileFilter(filter);
        int result = fileChooser.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            path = selectedFile.getAbsolutePath();
            String path2 = selectedFile.toURI().toURL().toString();
            Image image = new Image(path2);
            imageViewProduit.setImage(image);
        } else if (result == JFileChooser.CANCEL_OPTION) {
            System.out.println("NoData");
        }
    }

//    private void modifierProduit(ActionEvent event) throws SQLException  {
//        
//       
//        Produit p = new Produit(
//                    Integer.parseInt(txtId_produit.getText(),
//                    txtLibelle.getText(),
//                    txtCategorie.getText(),
//                    txtDate.getText(),
//                    Float.parseFloat(txtPrix.getText()),
//                    Integer.parseInt(txtQuantite.getText()),txtDescription.getText(), Integer.parseInt(txtNote.getText()))) ;
//                   
//            int item = Integer.parseInt(txtId_produit.getText());
//            Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
//            alert1.setTitle("Confirmation Dialog");
//            alert1.setContentText("Etes vous sur de vouloir modifier le produit ");
//            alert1.setHeaderText(null);
//            Optional<ButtonType> action = alert1.showAndWait();
//            if (action.get() == ButtonType.OK) {
//                ProduitService sv=new ProduitService();
//                sv.ModifierProduit(p, item);
//
//            }
//            System.out.println("Produit" + " " + txtId_produit.getText()+" " + "modifier avec succés");
//
//        }
    private void modifierProduit1(MouseEvent event) throws SQLException {

//        ProduitService ps = new ProduitService();
//        System.out.println("test");
//        Produit p = new Produit(Integer.parseInt(txtId_produit.getText()), txtLibelle.getText(), txtCategorie.getText(), txtDate.getText(), Float.parseFloat(txtPrix.getText()), Integer.parseInt(txtQuantite.getText()), txtDescription.getText(), Integer.parseInt(txtNote.getText()));
//        System.out.println("test2");
//        int x = Integer.parseInt(txtId_produit.getText());
//        ps.ModifierProduit(p, x);
//        Alert a = new Alert(Alert.AlertType.INFORMATION);
//        a.setContentText("Produit Modifié");
//        a.show();
    }

    @FXML
    private void modifierProduit11(MouseEvent event) throws SQLException {
         ProduitService ps = new ProduitService();
        System.out.println("test");
        Produit p = new Produit(Integer.parseInt(txtId_produit.getText()), txtLibelle.getText(), txtCategorie.getText(), Float.parseFloat(txtPrix.getText()),  txtDate.getText(),Integer.parseInt(txtQuantite.getText()), txtDescription.getText());
//        p  = (Produit)(.getSelectionModel().getSelectedItem());
//                 System.out.println(c);
              Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation du  suppression");
        alert.setHeaderText("Confirmation de supprission");
        alert.setContentText("étes-vous Sur ?");
//System.out.print(r.getId_facture());
Optional<ButtonType> result = alert.showAndWait();
if (result.get() == ButtonType.OK){
        if( ps.ModifierProduit(p)==true){
            System.out.println("c bon");
             Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText("Produit Modifié");
        a.show();
        } }
        else {
              Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setContentText("Produit non" );
        }
       
    }

    @FXML
    private void retour(ActionEvent event) throws IOException {
         //////redirectin////////
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AfficherProduit.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.initStyle(StageStyle.UNDECORATED);
        stage.setTitle("Afficher produit");
        stage.setScene(new Scene(root1));
        stage.show();
    }
    
}
