/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.GUI;

import cutpete.entitees.Produit;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import cutpete.service.ProduitService;
import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author zaine
 */
public class AjouterProduitController implements Initializable {

    @FXML
    private Button ButtonAjouter;
    @FXML
    private Button btnImportImage;
    String path = "";
    @FXML
    private ImageView imageViewProduit;
    @FXML
    private TextField txtLibelle;
    @FXML
    private TextField txtCategorie;
    @FXML
    private TextField txtDate;
    @FXML
    private TextField txtPrix;
    @FXML
    private TextField txtQuantite;
    @FXML
    private TextField txtDescription;
    @FXML
    private TextField txtNote;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void importImage(ActionEvent event) throws MalformedURLException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE", "jpg", "gif", "png");
        fileChooser.addChoosableFileFilter(filter);
        int result = fileChooser.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            path = selectedFile.getAbsolutePath();
            String path2 = selectedFile.toURI().toURL().toString();
            Image image = new Image(path2);
            imageViewProduit.setImage(image);
        } else if (result == JFileChooser.CANCEL_OPTION) {
            System.out.println("NoData");
        }
    }

    @FXML
    private void ajouterProduit(ActionEvent event) throws SQLException {
        String libelle = txtLibelle.getText();
        String categorie = txtCategorie.getText();
        String dateexp =txtDate.getText();
        Float prix = Float.parseFloat(txtPrix.getText());
        int Qte = Integer.parseInt(txtQuantite.getText());
        String desc = txtDescription.getText();
        int note =Integer.parseInt(txtNote.getText());

         
        Produit p = new Produit(libelle,categorie,prix,dateexp,Qte,desc,note);
        ProduitService pcd = new ProduitService();
        pcd.ajouterProduit(p);
        JOptionPane.showMessageDialog(null,"Produit ajouté !");

    }

//    private boolean validateInputs() {
//        return false;
//        
//    }

    @FXML
    private void retour(ActionEvent event) throws IOException {
         //////redirectin////////
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AfficherProduit.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.initStyle(StageStyle.UNDECORATED);
        stage.setTitle("Afficher produit");
        stage.setScene(new Scene(root1));
        stage.show();
    }

}
