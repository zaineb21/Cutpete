/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cutpete.GUI;

import cutpete.entitees.Produit;
import cutpete.entitees.Promotion;
import cutpete.service.ProduitService;
import cutpete.service.PromotionService;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author zaine
 */
public class ListeProduitFrontController implements Initializable {

    @FXML
    private TableView<Produit> tableProd;
    @FXML
    private ComboBox categorieprod;
    @FXML
    private TableColumn<Produit, String> libelleP;
    @FXML
    private TableColumn<Produit, String> selectedP;
    @FXML
    private TableColumn<Produit, String> dateP;
    @FXML
    private TableColumn<Produit, Float> prixP;
    @FXML
    private TableColumn<Produit, String> descP;
    @FXML
    private TableColumn<Produit, Integer> noteP;
    @FXML
    private TableColumn<Produit, String> imageP;
    @FXML
    private TableColumn<Produit, Integer> id_produitP;
     List listCategorie;
     ObservableList options = FXCollections.observableArrayList();
     //ObservableList optionsP = FXCollections.observableArrayList();
     List<Produit> listProduit;
      ObservableList<Produit> listViewProduit;
    @FXML
    private TextField id_produitVolu;
    @FXML
    private TextField prixPromot;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
          FillCategorie();
    }    
    private void FillCategorie() {
        try {
            ProduitService sr = new ProduitService();
            listCategorie = new ArrayList<>();
            listCategorie = sr.selectCategorieProduit();
            listCategorie.add("All");
            options = FXCollections.observableArrayList(listCategorie);
            categorieprod.setItems(options);
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }

    @FXML
    private void categorieprod(ActionEvent event) {
        FillCategorie();
    }
    private void setCellValue() {
        libelleP.setCellValueFactory(new PropertyValueFactory<>("libelle_produit"));
        selectedP.setCellValueFactory(new PropertyValueFactory<>("select"));
        dateP.setCellValueFactory(new PropertyValueFactory<>("date_expiration"));
        prixP.setCellValueFactory(new PropertyValueFactory<>("prix"));
        descP.setCellValueFactory(new PropertyValueFactory<>("description"));
        noteP.setCellValueFactory(new PropertyValueFactory<>("note"));
        imageP.setCellValueFactory(new PropertyValueFactory<>("image"));
        id_produitP.setCellValueFactory(new PropertyValueFactory<>("id_produit"));
        
    }
 private void AfficherData() {
        try {
            ProduitService sr = new ProduitService();
            listProduit = new ArrayList<>();
            if (categorieprod.getValue() == "All") {
                System.out.println("OKKKK ALLL");
                listProduit = sr.selectAllProduit();
            } else {
                listProduit = sr.selectProduit(categorieprod.getSelectionModel().getSelectedItem().toString());
            }
            listViewProduit = FXCollections.observableArrayList(listProduit);
            tableProd.setItems(listViewProduit);
            setCellValue();
        } catch (SQLException ex) {
            System.out.println(ex);
        }

    }
    @FXML
    private void AfficherProd(ActionEvent event) {
        AfficherData();
    }

    @FXML
    private void prixPromot(ActionEvent event) {
        PromotionService ps= new PromotionService();
        
        float a=0;
        a=ps.CalculPrixPromotion(Integer.parseInt(id_produitVolu.getText()));
        prixPromot.setText(Float.toString(a) +"DT");
    }
}